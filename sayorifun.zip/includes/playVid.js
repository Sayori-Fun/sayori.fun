function playVid(){
var vid = document.getElementById("bgvid");
		vid.play();
// There is no stopping the meme train CHOOO CHOOOO
};

window.onload = function() {
    var backgroundAudio=document.getElementById("bgvid");
    backgroundAudio.volume=0.7;
}
