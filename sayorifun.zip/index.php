<!DOCTYPE html>
<html>
<head>
<title>G̸̘̥͖̓̿E̸̜̦͛̀͛͒T̸͍̖̦̞͂Ö̶̟̫́͗Ư̶̦̱̌͘T̷̲̟͊͝ͅO̷̢̬̻̅̆̽̈ͅF̵̧̄͗̀M̴͑͗͜Y̷̛̞̟̟̆̽̈́H̶̢̛͊̕͝E̶̝͍͛͠Ã̸̛̳̪͇̽̀D̴͍͕͘͝͠</title>

<?php 

$metaKeywords = 'doki doki literature club, ddlc, sayori, secret';
require('includes/head.html');

?>
<link rel="stylesheet" type="text/css" href="includes/style.videopage.css">
<script async="true" src="includes/playVid.js"></script>

</head>


<body>
	<?php

		require('includes/body-sayorisecret.html');

	?>
	
</body>
</html>